from copy import deepcopy

from m3.compact_person import compact_person_evidence, on_demand_person_evidence
from m3.index_episodic import build_retrieval_text


def test_compaction_preserves_claims_without_modifying_source():
    binding = {
        "person_id": "person_123",
        "face_id": "face_hash",
        "association_status": "model_claim",
        "identity_status": "visual_proposal",
        "name_evidence": "Hello Alice",
    }
    characters = [{"name": "Alice", "person_binding": binding}]
    events = [{"summary": "Alice waves", "person_bindings": [binding]}]
    original = deepcopy((characters, events))
    compact_characters, compact_events = compact_person_evidence(characters, events)
    assert (characters, events) == original
    assert compact_characters[0]["person_binding"] == {
        "person_id": "person_123",
        "local_alias": "P1",
        "association_status": "model_claim",
        "identity_status": "visual_proposal",
        "name_evidence": "Hello Alice",
    }
    assert compact_events[0]["person_bindings"] == [{"local_alias": "P1"}]


def test_embedding_opt_in_removes_metadata_not_text(monkeypatch):
    record = {
        "description": "Alice waves",
        "person_grounding": {"video_id": "v"},
        "characters": [{"name": "Alice", "person_binding": {
            "person_id": "person_123", "face_content_sha256": "longhash"}}],
        "events": [{"summary": "Alice waves", "person_bindings": [
            {"person_id": "person_123"}]}],
    }
    monkeypatch.delenv("OGMEM_M3_COMPACT_PERSON", raising=False)
    original = build_retrieval_text(record)
    monkeypatch.setenv("OGMEM_M3_COMPACT_PERSON", "1")
    compact = build_retrieval_text(record)
    assert "longhash" in original
    assert "longhash" not in compact
    assert "Alice waves" in compact
    assert "Alice" in compact


def test_on_demand_keeps_observations_and_self_contained_bindings():
    binding = {"person_id": "person_123", "face_id": "face_hash"}
    characters = [{"name": "Alice", "person_binding": binding}]
    events = [{"summary": "Alice waves", "person_bindings": [binding]}]
    plain_characters, plain_events = on_demand_person_evidence(
        characters, events, "Where is the cup?", "cup location")
    assert plain_characters == [{"name": "Alice"}]
    assert plain_events == [{"summary": "Alice waves"}]
    named_characters, named_events = on_demand_person_evidence(
        characters, events, "What did Alice do?", "waving")
    assert named_characters[0]["person_binding"]["person_id"] == "person_123"
    assert named_events[0]["person_bindings"] == [{"person_id": "person_123"}]
    assert characters[0]["person_binding"] == binding
