"""Grouped wire evidence preserves admitted source values and bounded references."""
import json
from copy import deepcopy

import pytest

from m3.context_budget import ContextBudget, model_document, pack_context, request_units


def source():
    return {
        "node_id": "n1", "video_id": "video", "clip_id": 3,
        "source_start_sec": 90, "source_end_sec": 120,
        "description": "剪刀在桌上。 The scissors are on the desk.",
        "speech_transcript": [
            {"start_sec": i, "end_sec": i + .5, "text": f"Scissors action {i}.",
             "speaker_id": "SPEAKER_00", "confidence": .91}
            for i in range(20)
        ],
        "events": [{"type": "action", "ts_sec": i, "summary": f"Scissors step {i}"} for i in range(5)],
        "characters": [{"name": "Unknown", "description": "No resolved identity."}],
        "entities": [{"name": "Scissors", "location": {"relation": "on", "object": "desk"}}],
    }


def messages():
    result = [{"role": "user", "content": "What happened to the scissors?"}]
    for call in ("a", "b"):
        result.extend([
            {"role": "assistant", "tool_calls": [{"id": call, "type": "function",
             "function": {"name": "Search", "arguments": '{"query":"scissors"}'}}]},
            {"role": "tool", "tool_call_id": call, "content": json.dumps({
                "query": "scissors", "hits": [source()], "context_hits": [], "boundary_hits": []})},
        ])
    return result


def docs(view):
    packets = [json.loads(m["content"]) for m in view if m["role"] == "tool"]
    evidence = {key: value for p in packets for key, value in p["evidence"].items()}
    assert all(ref["id"] in evidence for p in packets for ref in p["evidence_refs"])
    return packets, evidence


def test_grouping_preserves_all_admitted_values_and_source_selectors():
    raw = messages()
    before = deepcopy(raw)
    options = dict(context_window=200000, max_input_tokens=180000)
    plain, ps = pack_context(raw, [], "scissors", ContextBudget(**options))
    grouped, gs = pack_context(raw, [], "scissors",
                               ContextBudget(**options, evidence_format="grouped"))
    assert raw == before
    pdoc, gdoc = next(iter(docs(plain)[1].values())), next(iter(docs(grouped)[1].values()))
    assert ps["selected_sources"] == gs["selected_sources"]
    assert ps["selected_passages"] == gs["selected_passages"] == 28
    assert "content_sha256" not in gdoc
    assert len(gs["selected_sources"][0]["content_sha256"]) == 64
    assert gdoc["node_id"] == pdoc["node_id"] == "n1"
    for passage in pdoc["passages"]:
        field = passage["field"]
        expected = ([passage["start_char"], passage["end_char"], passage["text"]]
                    if field == "description" else [passage["index"], passage["value"]])
        assert expected in gdoc[field]
    # No fields from the original admitted values (including uncertainty,
    # timing and nested spatial relations) may be stripped.
    assert [value for _, value in gdoc["speech_transcript"]] == source()["speech_transcript"]
    assert gdoc["entities"][0][1] == source()["entities"][0]
    assert request_units(grouped, []) < request_units(plain, [])


def test_grouped_view_is_bounded_and_does_not_duplicate_documents():
    # Enough for the coherent description+speech bundle, but not all optional
    # character/event/entity entries. Smaller budgets legitimately omit it.
    budget = ContextBudget(evidence_format="grouped", max_input_tokens=4500)
    view, stats = pack_context(messages(), [], "scissors", budget)
    packets, evidence = docs(view)
    assert len(evidence) == 1
    assert packets[1]["evidence"] == {}
    assert packets[0]["evidence_refs"][0]["id"] == packets[1]["evidence_refs"][0]["id"]
    assert request_units(view, [], budget) <= budget.input_limit
    assert stats["evidence_format"] == "grouped"
    assert stats["selected_passages"] < 28
    assert "not persistent entity IDs or event counts" in packets[0]["notice"]


def test_changed_source_version_is_not_deduplicated_by_grouping():
    raw = messages()
    payload = json.loads(raw[-1]["content"])
    payload["hits"][0]["source_end_sec"] = 110
    payload["hits"][0]["speech_transcript"] = source()["speech_transcript"][:10]
    raw[-1]["content"] = json.dumps(payload)
    view, stats = pack_context(raw, [], "scissors", ContextBudget(evidence_format="grouped"))
    assert len(docs(view)[1]) == 2
    assert stats["unique_evidence_versions"] == 2


def test_model_document_keeps_plain_mode_identical():
    document = {"node_id": "n", "passages": [], "content_sha256": "hash"}
    assert model_document(document, "passages") is document


def test_columnar_format_round_trips_all_original_values():
    raw = messages()
    before = deepcopy(raw)
    options = dict(context_window=200000, max_input_tokens=180000)
    grouped, grouped_stats = pack_context(
        raw, [], "scissors", ContextBudget(**options, evidence_format="grouped"))
    columnar, columnar_stats = pack_context(
        raw, [], "scissors", ContextBudget(**options, evidence_format="columnar"))
    assert raw == before
    assert grouped_stats["selected_sources"] == columnar_stats["selected_sources"]
    grouped_document = next(iter(docs(grouped)[1].values()))
    columnar_document = next(iter(docs(columnar)[1].values()))
    for field in ("speech_transcript", "events", "characters", "entities"):
        value = columnar_document[field]
        if isinstance(value, dict) and "columns" in value:
            columns = value["columns"]
            decoded = [[row[0], dict(zip(columns[1:], row[1:]))] for row in value["rows"]]
        else:
            decoded = value
        assert decoded == grouped_document[field]
    assert columnar_document["description"] == grouped_document["description"]
    assert request_units(columnar, []) < request_units(grouped, [])


def test_columnar_keeps_heterogeneous_entries_in_grouped_format():
    document = {"node_id": "n", "passages": [
        {"field": "speech_transcript", "index": 0, "value": {"text": "a", "speaker": "X"}},
        {"field": "speech_transcript", "index": 1, "value": {"text": "b"}},
    ]}
    assert model_document(document, "columnar")["speech_transcript"] == [
        [0, {"text": "a", "speaker": "X"}], [1, {"text": "b"}]]


def test_grouped_prompt_does_not_promote_local_indices_to_entity_identities():
    from unittest.mock import Mock
    from core.models import RequestContext
    from m3.control_adapter import OGMemoryControlAdapter, M3TaskContext

    adapter = OGMemoryControlAdapter(Mock(), Mock(), Mock(),
                                    context_budget=ContextBudget(evidence_format="grouped"))
    ctx = RequestContext(account_id="a", user_id="u", agent_id="g", session_id="s", trace_id="t")
    prompt = adapter._build_messages(ctx, M3TaskContext(question="Who moved the object?"))[0]["content"]
    assert "local to a field in one clip" in prompt
    assert "not persistent person/object identity IDs across clips" in prompt


@pytest.mark.parametrize("value", ["unknown", None, True, {}, []])
def test_invalid_evidence_format_rejected(value):
    with pytest.raises(ValueError, match="evidence_format"):
        ContextBudget(evidence_format=value)
