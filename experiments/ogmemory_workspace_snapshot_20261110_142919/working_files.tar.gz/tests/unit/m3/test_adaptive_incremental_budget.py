import pytest

from m3.context_budget import ContextBudget
from m3.control_adapter import _incremental_budget_for_call
from m3.incremental_context import IncrementalContext
from tests.unit.m3.test_context_budget import exchange, hit, messages


def test_later_budget_preserves_first_evidence_and_original(monkeypatch):
    monkeypatch.setenv("OGMEM_M3_LATER_INCREMENTAL_TOKENS", "2000")
    budget = ContextBudget(incremental_delivery=True, incremental_tokens=3500)
    assert _incremental_budget_for_call(budget, False) is budget
    later = _incremental_budget_for_call(budget, True)
    assert later.incremental_tokens == 2000
    assert budget.incremental_tokens == 3500
    assert later.input_limit == budget.input_limit


@pytest.mark.parametrize("value", ["0", "-1", "3501", "bad"])
def test_invalid_later_budget_is_rejected(monkeypatch, value):
    monkeypatch.setenv("OGMEM_M3_LATER_INCREMENTAL_TOKENS", value)
    with pytest.raises(ValueError, match="OGMEM_M3_LATER_INCREMENTAL_TOKENS"):
        _incremental_budget_for_call(
            ContextBudget(incremental_delivery=True, incremental_tokens=3500), True)


def test_later_budget_is_opt_in_and_only_applies_to_incremental(monkeypatch):
    budget = ContextBudget(incremental_delivery=True)
    monkeypatch.delenv("OGMEM_M3_LATER_INCREMENTAL_TOKENS", raising=False)
    assert _incremental_budget_for_call(budget, True) is budget
    monkeypatch.setenv("OGMEM_M3_LATER_INCREMENTAL_TOKENS", "1000")
    non_incremental = ContextBudget(incremental_delivery=False)
    assert _incremental_budget_for_call(non_incremental, True) is non_incremental


def test_later_packing_preserves_first_evidence_and_respects_increment(monkeypatch):
    monkeypatch.setenv("OGMEM_M3_LATER_INCREMENTAL_TOKENS", "1200")
    budget = ContextBudget(fact_memory=True, incremental_delivery=True,
                           incremental_tokens=3500, max_input_tokens=12000)
    state = IncrementalContext()
    raw = messages(exchange("first", "scissors", [hit(text="Scissors are on the desk.")]))
    first, first_stats = state.pack(raw, [], "scissors",
                                    _incremental_budget_for_call(budget, False))
    assert first_stats["new_selected_passages"] > 0
    raw.extend(exchange("second", "glue", [hit("other", text="Glue is inside the box.")]))
    second, stats = state.pack(raw, [], "scissors",
                               _incremental_budget_for_call(budget, True))
    assert second[:len(first)] == first
    assert stats["new_selected_passages"] > 0
    assert stats["estimated_input_tokens"] <= stats["non_evidence_input_tokens"] + 1200
