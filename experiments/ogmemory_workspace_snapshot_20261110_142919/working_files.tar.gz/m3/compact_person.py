"""Compact model-facing person evidence without changing stored memories."""

import os
import re
from copy import deepcopy


def enabled():
    return os.environ.get("OGMEM_M3_COMPACT_PERSON") == "1"


def on_demand_person_evidence(characters, events, question, query):
    text = f"{question} {query}"
    needs_person = bool(re.search(
        r"\b(who|whose|person|people|character|speaker|speaking|said|says|"
        r"name|named|identity|face|he|she|him|her|his|hers|they|them|their)\b"
        r"|人物|人脸|姓名|名字|谁|说话|他|她",
        text, re.IGNORECASE,
    ))
    if not needs_person:
        for character in characters:
            if not isinstance(character, dict):
                continue
            name = character.get("name")
            if isinstance(name, str) and len(name.strip()) >= 3 and re.search(
                r"(?<!\w)" + re.escape(name.strip()) + r"(?!\w)", text, re.IGNORECASE
            ):
                needs_person = True
                break
    characters = deepcopy(characters)
    events = deepcopy(events)
    if not needs_person:
        for character in characters:
            if isinstance(character, dict):
                character.pop("person_binding", None)
        for event in events:
            if isinstance(event, dict):
                event.pop("person_bindings", None)
        return characters, events
    characters, events = compact_person_evidence(characters, events)
    aliases = {
        binding["local_alias"]: binding["person_id"]
        for character in characters if isinstance(character, dict)
        for binding in [character.get("person_binding")]
        if isinstance(binding, dict) and binding.get("local_alias") and binding.get("person_id")
    }
    for event in events:
        if not isinstance(event, dict) or not isinstance(event.get("person_bindings"), list):
            continue
        for binding in event["person_bindings"]:
            if isinstance(binding, dict) and binding.get("local_alias") in aliases:
                binding["person_id"] = aliases[binding["local_alias"]]
                del binding["local_alias"]
    return characters, events


def compact_person_evidence(characters, events):
    characters = deepcopy(characters)
    events = deepcopy(events)
    aliases = {}
    for character in characters:
        if not isinstance(character, dict):
            continue
        binding = character.get("person_binding")
        if not isinstance(binding, dict) or not isinstance(binding.get("person_id"), str):
            continue
        person_id = binding["person_id"]
        alias = aliases.setdefault(person_id, f"P{len(aliases) + 1}")
        compact = {"person_id": person_id, "local_alias": alias}
        for key in ("identity_status", "association_status", "name_evidence"):
            if key in binding:
                compact[key] = binding[key]
        character["person_binding"] = compact
    for event in events:
        if not isinstance(event, dict):
            continue
        bindings = event.get("person_bindings")
        if not isinstance(bindings, list):
            continue
        compact_bindings = []
        for binding in bindings:
            if not isinstance(binding, dict):
                compact_bindings.append(binding)
                continue
            person_id = binding.get("person_id")
            if person_id in aliases:
                compact_bindings.append({"local_alias": aliases[person_id]})
            else:
                compact_bindings.append({
                    key: binding[key] for key in
                    ("person_id", "identity_status", "association_status", "name_evidence")
                    if key in binding
                })
        event["person_bindings"] = compact_bindings
    return characters, events
